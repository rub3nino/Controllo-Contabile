# Documenti mancanti

Cliente: Cliente Demo
Periodo: Aprile - Giugno 2026

- **A.1** Cambiamenti SCI / sistema contabile-amministrativo
- **A.2** Operazioni straordinarie, contratti, passività potenziali
- **A.3** Cartelle, avvisi bonari, comunicazioni AE/INPS
- **A.4** Transazioni finanziarie non ordinarie
- **B.2** CE gestionale vs budget
- **B.3** Budget e cashflow
- **B.4** Libro giornale provvisorio / mastrini
- **C.1** Verbali assemblee soci
- **C.3** Verbali Collegio sindacale
- **C.4** Libro soci
- **D.1** Libro giornale definitivo (bollato)
- **D.2** Libro inventari
- **D.3** Registri IVA
- **E.2** Fondi previdenziali
- **E.4** Dichiarazione annuale IVA
- **F.2** Riconciliazioni bancarie
- **F.3** Centrale Rischi
- **G.1** Cedolini / LUL / prima nota personale
- **G.2** Contabile pagamento stipendi
